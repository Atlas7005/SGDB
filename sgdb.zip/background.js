chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if(request.x == "creategroup") {
        const { slug } = request;
        if(!slug) return sendResponse({ error: "Slug is required" });

        fetch("https://ec2-3-122-252-244.eu-central-1.compute.amazonaws.com/api/groups/"+slug.toLowerCase(), {
            method: "POST"
        }).then(response => {
            return response.json();
        }).then(data => {
            sendResponse(data);
        }).catch(error => {
            sendResponse({ error: error });
        });
    }
    return true;
});